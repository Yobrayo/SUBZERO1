module.exports = {
  SESSION_ID: "", // Put Session Id Here Inside "*"
  OWNER_NUMBER: "263719647303", // Put Owner Number Here 
  PREFIX: ".", // Default Prefix You Can Change To .,*!?+-&%#@
  CDN: "https://mrfrankk-cdn.hf.space" // Dont change this part
};

// CREATED BY DARRELL MUCHERI ( MR FRANK OFC 🇿🇼 )
